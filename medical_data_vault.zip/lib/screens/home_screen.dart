import 'package:flutter/material.dart';
import 'add_edit_form.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Map<String, String>> patients = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Medical Data Vault')),
      body: patients.isEmpty
          ? const Center(child: Text('No records yet.'))
          : ListView.builder(
              itemCount: patients.length,
              itemBuilder: (context, index) {
                final p = patients[index];
                return ListTile(
                  title: Text(p['name'] ?? 'No Name'),
                  subtitle: Text('Age: ${p['age'] ?? ''}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () async {
                      final updated = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AddEditForm(data: p),
                        ),
                      );
                      if (updated != null) {
                        setState(() {
                          patients[index] = updated;
                        });
                      }
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newPatient = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddEditForm()),
          );
          if (newPatient != null) {
            setState(() {
              patients.add(newPatient);
            });
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}